# Retailer API server

Yeh server aapke Firebase database se connect hota hai aur retailers ko API deta hai.
Database ya rules mein koi badlav nahi chahiye.

## Chalane ke steps (Render.com par, free)
1. Firebase Console → Project settings → Service accounts → **Generate new private key**. Ek JSON file milegi.
2. Yeh `api-server` folder GitHub par daalo, phir Render.com par **New → Web Service** banao.
   - Build command: `npm install`
   - Start command: `npm start`
3. Render mein **Environment** mein ek variable banao:
   - `FIREBASE_SERVICE_ACCOUNT` = us JSON file ka poora text
4. Deploy hone par Render ek link dega, jaise `https://zx-api.onrender.com`. Wahi aapka **Base URL** hai.
5. Admin panel → More → Retailer API mein Base URL paste karke Save karo.
6. Admin panel → Retailers → **Make API token** dabao. Token copy ho jata hai.
7. Base URL + token jisko dena hai usko bhej do.

## Endpoints (header: `X-API-Key: <token>`)
- `GET /balance`
- `GET /plans`
- `POST /purchase` body: `{"plan":"<PLAN_ID>","username":"customer","maxDevices":1}` (optional `"key"`)
- `GET /keys`
- `POST /reset-devices` body: `{"key":"FIXA-..."}`

Kharcha retailer ke balance se kat'ta hai, discount ke saath, bilkul panel jaisa.

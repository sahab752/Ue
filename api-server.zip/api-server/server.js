// ZX RAHUL Retailer API — reads/writes the same Firebase DB as the admin & retailer panels.
// Each retailer has their own token (made in admin panel → Retailers → "Make API token").
const express = require("express");
const admin = require("firebase-admin");

const cred = process.env.FIREBASE_SERVICE_ACCOUNT
  ? admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT))
  : admin.credential.applicationDefault();
admin.initializeApp({
  credential: cred,
  databaseURL: process.env.DATABASE_URL || "https://zxsajan-default-rtdb.firebaseio.com",
});
const db = admin.database();
const KEYS = "FIXA_MODS", RET = "FIXA_RETAILERS", CONFIG = "FIXA_CONFIG", ACT = "ADMIN_ACTIVITY";

const app = express();
app.use(express.json({ limit: "20kb" }));
app.use((req, res, next) => {
  res.set({
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "X-API-Key, Content-Type",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  });
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

const wrap = (fn) => (req, res) =>
  fn(req, res).catch((e) => {
    console.error(e);
    res.status(500).json({ ok: false, error: "Server error" });
  });

// 60 requests / minute / token
const hits = new Map();
function rateOk(t) {
  const now = Date.now();
  const arr = (hits.get(t) || []).filter((x) => now - x < 60000);
  arr.push(now);
  hits.set(t, arr);
  return arr.length <= 60;
}

async function auth(req, res, next) {
  try {
    const t = String(req.get("x-api-key") || "").trim();
    if (t.length < 20) return res.status(401).json({ ok: false, error: "Invalid API key" });
    if (!rateOk(t)) return res.status(429).json({ ok: false, error: "Too many requests" });
    const snap = await db.ref(RET).orderByChild("apiToken").equalTo(t).limitToFirst(1).once("value");
    const v = snap.val();
    if (!v) return res.status(401).json({ ok: false, error: "Invalid API key" });
    const id = Object.keys(v)[0];
    const r = v[id];
    if (String(r.status).toUpperCase() !== "ACTIVE")
      return res.status(403).json({ ok: false, error: "Account not active" });
    req.rid = id;
    req.ret = r;
    next();
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: "Server error" });
  }
}

const price = (p, discount) => Math.max(0, Math.round((Number(p.price) * (100 - (Number(discount) || 0))) / 100));
const autoKey = () => {
  const c = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const g = () => Array.from({ length: 4 }, () => c[Math.floor(Math.random() * c.length)]).join("");
  return `FIXA-${g()}-${g()}-${g()}`;
};
const logAct = (action, key, name) =>
  db.ref(ACT).push({ action, key: key || "", time: new Date().toISOString(), admin: "api:" + name }).catch(() => {});

async function getPlans() {
  const v = (await db.ref(`${CONFIG}/retailerPricing`).once("value")).val() || {};
  return Object.entries(v)
    .map(([id, x]) => ({ ...x, id }))
    .filter((x) => x.enabled !== false && x.price !== "" && x.price != null && Number(x.price) >= 0)
    .sort((a, b) => (a.sort || 0) - (b.sort || 0));
}

app.get("/", (req, res) => res.json({ ok: true, service: "retailer-api" }));
app.get("/health", (req, res) => res.json({ ok: true }));

app.get("/balance", auth, wrap(async (req, res) => {
  const credits = (await db.ref(`${RET}/${req.rid}/credits`).once("value")).val() || 0;
  res.json({ ok: true, name: req.ret.name || "", balance: credits, discount: Number(req.ret.discount) || 0 });
}));

app.get("/plans", auth, wrap(async (req, res) => {
  const plans = await getPlans();
  res.json({
    ok: true,
    plans: plans.map((p) => ({ id: p.id, label: p.label, duration: p.value, unit: p.unit, price: price(p, req.ret.discount) })),
  });
}));

app.post("/purchase", auth, wrap(async (req, res) => {
  const b = req.body || {};
  const plan = (await getPlans()).find((p) => p.id === String(b.plan || ""));
  if (!plan) return res.status(400).json({ ok: false, error: "Unknown plan" });
  const username = String(b.username || "").trim().slice(0, 60);
  if (!username) return res.status(400).json({ ok: false, error: "username required" });
  const mx = parseInt(b.maxDevices, 10) || 1;
  if (mx < 1 || mx > 20) return res.status(400).json({ ok: false, error: "maxDevices must be 1-20" });
  const key = String(b.key || "").trim() || autoKey();
  if (!/^[A-Za-z0-9_-]{4,64}$/.test(key)) return res.status(400).json({ ok: false, error: "Invalid key format" });

  const cost = price(plan, req.ret.discount);
  const credRef = db.ref(`${RET}/${req.rid}/credits`);
  // null → return 0 so Firebase retries with the real server value
  const tx = await credRef.transaction((n) => (n === null ? 0 : n >= cost ? n - cost : undefined));
  if (!tx.committed) {
    const bal = (await credRef.once("value")).val() || 0;
    return res.status(402).json({ ok: false, error: "Not enough balance", balance: bal, price: cost });
  }
  const rec = {
    username, status: "ACTIVE", keyStatus: "ACTIVE", validityMode: "duration", maxDevices: mx,
    durationValue: plan.value, durationUnit: plan.unit, validity: "", firstLogin: "", lastLogin: "",
    createdAt: new Date().toISOString(), retailerId: req.rid, retailerName: req.ret.name || "",
    parentId: req.ret.parentId || "", price: cost, planLabel: plan.label, planId: plan.id, createdVia: "api",
  };
  const kt = await db.ref(`${KEYS}/${key}`).transaction((cur) => (cur === null ? rec : undefined));
  if (!kt.committed) {
    await credRef.transaction((n) => (n || 0) + cost); // refund
    return res.status(409).json({ ok: false, error: "Key already exists" });
  }
  logAct(`Retailer Key Created via API (₹${cost})`, key, req.ret.name || req.rid);
  res.json({ ok: true, key, plan: plan.label, price: cost, balance: tx.snapshot.val() });
}));

app.get("/keys", auth, wrap(async (req, res) => {
  const snap = await db.ref(KEYS).orderByChild("retailerId").equalTo(req.rid).limitToLast(100).once("value");
  const v = snap.val() || {};
  const keys = Object.entries(v).map(([key, o]) => ({
    key, username: o.username, plan: o.planLabel, price: o.price, validity: o.validity || null,
    status: o.keyStatus || o.status, maxDevices: o.maxDevices,
    devices: o.devices ? Object.keys(o.devices).length : 0, createdAt: o.createdAt,
  }));
  res.json({ ok: true, keys });
}));

app.post("/reset-devices", auth, wrap(async (req, res) => {
  const key = String((req.body || {}).key || "").trim();
  if (!key) return res.status(400).json({ ok: false, error: "key required" });
  const o = (await db.ref(`${KEYS}/${key}`).once("value")).val();
  if (!o || o.retailerId !== req.rid) return res.status(404).json({ ok: false, error: "Key not found" });
  await db.ref(`${KEYS}/${key}/devices`).remove();
  logAct("Devices Reset via API", key, req.ret.name || req.rid);
  res.json({ ok: true });
}));

app.use((req, res) => res.status(404).json({ ok: false, error: "Not found" }));
app.listen(process.env.PORT || 3000, () => console.log("Retailer API running"));
